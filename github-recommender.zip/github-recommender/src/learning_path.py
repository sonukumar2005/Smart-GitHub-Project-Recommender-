def generate_learning_path(query):
    """
    Generate a simple learning path based on the predicted category or keywords.
    """
    query_lower = query.lower()
    
    if "python" in query_lower and "ai" in query_lower:
        return [
            "Learn Python basics (strings, lists, loops, functions)",
            "Master NumPy and Pandas for data manipulation",
            "Understand basic Machine Learning concepts with scikit-learn",
            "Dive into Deep Learning with PyTorch or TensorFlow"
        ]
    elif "web" in query_lower:
        return [
            "Learn HTML, CSS, and vanilla JS",
            "Learn a frontend framework like React or Vue",
            "Learn a backend language/framework (Node.js, Django, FastAPI)",
            "Understand databases (SQL/NoSQL) and deployment"
        ]
    else:
        return [
            "Research the topic fundamentals",
            "Find beginner tutorials on YouTube or freeCodeCamp",
            "Build a small, simple project",
            "Contribute to an open-source repository"
        ]
