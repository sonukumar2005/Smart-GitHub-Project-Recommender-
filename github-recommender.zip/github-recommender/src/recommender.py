import requests
import os
from dotenv import load_dotenv

load_dotenv()

def recommend_projects(user_input, top_n=10, sort_by='Stars', difficulty="All"):

    try:
        # 🔥 Difficulty-based query
        if difficulty == "Beginner":
            query = user_input + " stars:<500"
        elif difficulty == "Intermediate":
            query = user_input + " stars:500..5000"
        elif difficulty == "Advanced":
            query = user_input + " stars:>5000"
        else:
            query = user_input

        safe_query = requests.utils.quote(query)

        # 🔥 Sorting
        if sort_by == "Recently Updated":
            sort_param = "updated"
        elif sort_by == "Relevance":
            sort_param = ""
        else:
            sort_param = "stars"

        url = f"https://api.github.com/search/repositories?q={safe_query}&order=desc&per_page={top_n}"

        if sort_param:
            url += f"&sort={sort_param}"

        # 🔐 Token
        token = os.getenv("GITHUB_TOKEN")

        headers = {
            "Accept": "application/vnd.github.v3+json",
            "User-Agent": "github-recommender-app"
        }

        if token:
            headers["Authorization"] = f"token {token}"

        response = requests.get(url, headers=headers, timeout=10)

        print("STATUS:", response.status_code)

        if response.status_code == 200:
            data = response.json()
            items = data.get("items", [])

            results = []

            for item in items:
                stars = item.get("stargazers_count", 0)

                # 🎯 Difficulty classification
                if stars <= 500:
                    level = "Beginner"
                elif stars <= 5000:
                    level = "Intermediate"
                else:
                    level = "Advanced"

                results.append({
                    "name": item.get("full_name", "N/A"),
                    "url": item.get("html_url", "#"),
                    "description": item.get("description") or "No description provided.",
                    "stars": stars,
                    "forks": item.get("forks_count", 0),
                    "language": item.get("language") or "Unknown",
                    "updated_at": item.get("updated_at", "")[:10],
                    "difficulty": level
                })

            return results

        else:
            print("ERROR:", response.status_code, response.text)
            return []

    except Exception as e:
        print("ERROR:", e)
        return []
    # 2. Fallback mock dataset
    mock_db = [
        {
            "name": "tensorflow/tensorflow",
            "url": "https://github.com/tensorflow/tensorflow",
            "description": "An Open Source Machine Learning Framework for Everyone",
            "stars": 180000,
            "forks": 73000,
            "language": "Python",
            "updated_at": "2026-03-20"
        },
        {
            "name": "vinta/awesome-python",
            "url": "https://github.com/vinta/awesome-python",
            "description": "A curated list of awesome Python frameworks, libraries, software and resources",
            "stars": 195000,
            "forks": 25000,
            "language": "Python",
            "updated_at": "2026-03-19"
        },
        {
            "name": "scikit-learn/scikit-learn",
            "url": "https://github.com/scikit-learn/scikit-learn",
            "description": "Machine learning in Python",
            "stars": 60000,
            "forks": 25000,
            "language": "Python",
            "updated_at": "2026-03-18"
        },
        {
            "name": "hwchase17/langchain",
            "url": "https://github.com/hwchase17/langchain",
            "description": "Building applications with LLMs through composability",
            "stars": 75000,
            "forks": 11000,
            "language": "Python",
            "updated_at": "2026-03-20"
        },
        {
            "name": "huggingface/transformers",
            "url": "https://github.com/huggingface/transformers",
            "description": "State-of-the-art Machine Learning for PyTorch, TensorFlow, and JAX.",
            "stars": 120000,
            "forks": 23000,
            "language": "Python",
            "updated_at": "2026-03-21"
        },
        {
            "name": "pallets/flask",
            "url": "https://github.com/pallets/flask",
            "description": "The Python micro framework for building web applications.",
            "stars": 65000,
            "forks": 16000,
            "language": "Python",
            "updated_at": "2026-03-10"
        },
        {
            "name": "django/django",
            "url": "https://github.com/django/django",
            "description": "The Web framework for perfectionists with deadlines.",
            "stars": 74000,
            "forks": 29000,
            "language": "Python",
            "updated_at": "2026-03-15"
        },
        {
            "name": "tiangolo/fastapi",
            "url": "https://github.com/tiangolo/fastapi",
            "description": "FastAPI framework, high performance, easy to learn, fast to code, ready for production",
            "stars": 68000,
            "forks": 11000,
            "language": "Python",
            "updated_at": "2026-03-20"
        },
        {
            "name": "pandas-dev/pandas",
            "url": "https://github.com/pandas-dev/pandas",
            "description": "Flexible and powerful data analysis / manipulation library for Python",
            "stars": 40000,
            "forks": 16000,
            "language": "Python",
            "updated_at": "2026-03-19"
        },
        {
            "name": "keras-team/keras",
            "url": "https://github.com/keras-team/keras",
            "description": "Deep Learning for humans",
            "stars": 60000,
            "forks": 19000,
            "language": "Python",
            "updated_at": "2026-03-16"
        }
    ]

    # Sort mock data to simulate API behavior
    if sort_by == "Stars":
        mock_db = sorted(mock_db, key=lambda x: x["stars"], reverse=True)
    elif sort_by == "Recently Updated":
        mock_db = sorted(mock_db, key=lambda x: x["updated_at"], reverse=True)

    return mock_db[:top_n]
