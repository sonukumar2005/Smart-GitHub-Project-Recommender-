import os

def check_model_exists(model_path):
    """Check if the saved model exists in the specified path."""
    return os.path.exists(model_path)
