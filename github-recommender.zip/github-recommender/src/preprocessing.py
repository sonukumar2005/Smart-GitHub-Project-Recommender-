import pandas as pd
import re

def clean_text(text):
    """Clean and standardize input text."""
    if not isinstance(text, str):
        return ""
    text = text.lower()
    text = re.sub(r'[^a-z0-9\s+]', '', text)
    return text.strip()

def preprocess_data(filepath):
    """Load and preprocess the dataset."""
    try:
        df = pd.read_csv(filepath)
        df['clean_description'] = df['description'].apply(clean_text)
        return df
    except Exception as e:
        print(f"Error loading data: {e}")
        return None
