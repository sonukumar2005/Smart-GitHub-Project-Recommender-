# GitHub Recommender System

A Streamlit-based web application that recommends GitHub projects and learning paths based on user interests (e.g., "AI + Python").

## Workflow
User -> Streamlit UI -> Python Code (ML logic) -> Data/Model -> Streamlit UI (updated output)

## Project Structure
- `data/`: Dataset files (e.g., `github_projects.csv`)
- `notebooks/`: Jupyter notebooks for data exploration and model training
- `src/`: Core logic and helper functions
- `model/`: Saved Machine Learning models (e.g., TF-IDF vectorizers)
- `app/`: Streamlit web application
