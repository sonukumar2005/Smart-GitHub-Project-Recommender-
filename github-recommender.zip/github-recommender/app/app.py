import streamlit as st
import sys
import os
import time

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.recommender import recommend_projects
from src.learning_path import generate_learning_path

st.set_page_config(
    page_title="GitHub Recommender",
    page_icon="🌌",
    layout="wide",
    initial_sidebar_state="expanded"
)

st.markdown("""
<style>
    .title-text {
        background: -webkit-linear-gradient(45deg, #FF6B6B, #4ECDC4);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        font-size: 3em;
        font-weight: 800;
        margin-bottom: 0px;
        padding-bottom: 10px;
    }
    div.stButton > button {
        background: linear-gradient(90deg, #4ECDC4 0%, #556270 100%);
        color: white;
        border-radius: 8px;
        padding: 10px 24px;
        border: none;
        box-shadow: 0 4px 6px rgba(0,0,0,0.2);
        transition: all 0.3s ease 0s;
        font-weight: bold;
        width: 100%;
        margin-top: 28px;
    }
    div.stButton > button:hover {
        transform: translateY(-2px);
        box-shadow: 0px 8px 15px rgba(78, 205, 196, 0.4);
        border: none;
        color: white;
    }
</style>
""", unsafe_allow_html=True)

st.markdown('<div class="title-text">GitHub Project Explorer 🌌</div>', unsafe_allow_html=True)
st.markdown("**Discover top open-source projects and level up your skills with a custom roadmap.**")
st.markdown("---")

with st.sidebar:
    st.image("https://github.githubassets.com/images/modules/logos_page/GitHub-Mark.png", width=80)
    st.title("⚙️ Settings")
    top_n = st.slider("Projects to Recommend", min_value=1, max_value=10, value=3)
    sort_by = st.selectbox("Sort Projects By", ["Stars", "Recently Updated", "Relevance"])

    # ✅ NEW: Difficulty filter
    difficulty = st.selectbox("Filter by Difficulty", ["All", "Beginner", "Intermediate", "Advanced"])

    st.markdown("---")
    st.markdown("### About")
    st.info("This AI-powered tool recommends GitHub projects and generates a personalized learning roadmap based on your tech stack interests.")

col1, col2 = st.columns([4, 1])

with col1:
    user_input = st.text_input("What tech stack or topics are you interested in?", placeholder="e.g., Machine Learning, ReactJS, Web Automation...")

with col2:
    search_clicked = st.button("🚀 Discover Now")

st.markdown("<br>", unsafe_allow_html=True)

# ── Difficulty badge helper ──────────────────────────────────────────────────
def difficulty_badge(level):
    colors = {
        "Beginner":     ("#28a745", "🟢"),
        "Intermediate": ("#fd7e14", "🟠"),
        "Advanced":     ("#dc3545", "🔴"),
    }
    color, emoji = colors.get(level, ("#888", "⚪"))
    return (
        f'<span style="background:{color};color:#fff;padding:3px 10px;'
        f'border-radius:12px;font-size:0.8em;font-weight:bold;">'
        f'{emoji} {level}</span>'
    )

if search_clicked:
    if user_input.strip() == "":
        st.warning("⚠️ Please enter a topic to get started!")
    else:
        progress_text = st.empty()
        progress_bar = st.progress(0)

        for i in range(100):
            progress_bar.progress(i + 1)
            if i == 20:
                progress_text.text("🔍 Analyzing request keywords...")
            elif i == 50:
                progress_text.text("🌐 Fetching top repositories and indexing...")
            elif i == 80:
                progress_text.text("🛣️ Generating your customized learning path...")
            time.sleep(0.015)

        progress_bar.empty()
        progress_text.empty()
        st.balloons()

        # ✅ Pass difficulty to recommender
        projects = recommend_projects(user_input, top_n=top_n, sort_by=sort_by, difficulty=difficulty)
        learning_path = generate_learning_path(user_input)

        tab1, tab2 = st.tabs(["🎯 Recommended Projects", "🗺️ Your Learning Path"])

        with tab1:
            if projects:
                for idx, proj in enumerate(projects[:top_n]):
                    stars_formatted = f"{proj.get('stars', 0):,}"
                    updated_at = proj.get("updated_at", "N/A")
                    level = proj.get("difficulty", "N/A")
                    badge = difficulty_badge(level)

                    # ✅ FIX: Use st.container + st.markdown properly
                    with st.container():
                        st.markdown(
                            f"""
                            <div style="
                                background-color:#1E1E2E;
                                padding:20px;
                                border-radius:12px;
                                box-shadow:0 4px 6px rgba(0,0,0,0.1);
                                margin-bottom:20px;
                                border-left:5px solid #4ECDC4;
                            ">
                                <div style="display:flex;align-items:center;flex-wrap:wrap;gap:10px;">
                                    <a href="{proj['url']}" target="_blank"
                                       style="color:#4ECDC4;font-size:1.3em;font-weight:bold;text-decoration:none;">
                                        {idx+1}. {proj['name']} 🔗
                                    </a>
                                    <span style="color:#FFD700;font-weight:bold;">⭐ {stars_formatted}</span>
                                    {badge}
                                </div>
                                <div style="color:#e0e0e0;font-size:1.05em;margin-top:10px;">
                                    {proj['description']}
                                </div>
                                <div style="margin-top:10px;font-size:0.85em;color:#1E90FF;">
                                    🕒 Last updated: {updated_at}
                                    &nbsp;|&nbsp;
                                    🗂️ Language: {proj.get('language', 'Unknown')}
                                    &nbsp;|&nbsp;
                                    🍴 Forks: {proj.get('forks', 0):,}
                                </div>
                            </div>
                            """,
                            unsafe_allow_html=True,
                        )
            else:
                st.info("No projects found for this topic / difficulty. Try another keyword or filter!")

        with tab2:
            st.subheader("Journey to Mastery 🏆")
            for i, step in enumerate(learning_path):
                with st.expander(f"**Step {i+1}:** {step}"):
                    st.write("Focus on mastering this step thoroughly before moving to the next one.")
                    st.write(f"💡 *Tip: Search GitHub, YouTube, or freeCodeCamp for resources on '{step}' for excellent tutorials.*")